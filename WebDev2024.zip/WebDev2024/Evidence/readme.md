This lab introduces the basics of HTML.

Follow the [Wiki](https://github.com/mustbebuilt/webdev-html-introduction/wiki/01.-Getting-Started) guide.